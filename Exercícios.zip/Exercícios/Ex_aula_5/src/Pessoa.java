public class Pessoa {
    private String nome;
    private int idade;
}
