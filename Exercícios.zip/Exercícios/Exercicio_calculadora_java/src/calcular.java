import java.util.Scanner;

public class calcular{

    public static void somar(float numero1, float numero2){


        numero1 = numero1 + numero2;

        System.out.printf("Soma: %.2f\n", numero1);

        return;

    }

    public static void subtracao(float numero1, float numero2){

        numero1 = numero1 - numero2;
        System.out.printf("Subtracao: %.2f\n", numero1);

        return;

    }

    public static void multiplicacao(float numero1, float numero2){
        numero1 = numero1 * numero2;
        System.out.printf("Multiplicacao: %.2f\n", numero1);

        return;
    }

    public static void divisao(float numero1, float numero2){
        numero1 = numero1 / numero2;
        System.out.printf("Divisao: %.2f\n", numero1);

        return;
    }
}
