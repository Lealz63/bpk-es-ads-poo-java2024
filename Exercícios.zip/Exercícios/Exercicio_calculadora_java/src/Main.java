import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite um numero: ");
        float num1 = sc.nextFloat();


        System.out.println("Digite um numero: ");
        float num2 = sc.nextFloat();

        calcular cal = new calcular();

        cal.somar(num1 , num2);
        cal.subtracao(num1, num2);
        cal.multiplicacao(num1, num2);
        cal.divisao(num1, num2);

        return;

    }
}