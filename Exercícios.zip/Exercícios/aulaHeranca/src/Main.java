import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Cachorro meuCachorro = new Cachorro(Porte.GRANDE, "Marrom", "Labrador", "Rex", 5);

        Gato meuGato = new Gato(Porte.PEQUENO, "Branco", "Persa", "Mingau", 3);

        System.out.println("Detalhes do Cachorro:");
        System.out.println(meuCachorro.toString());

        meuCachorro.latir();

        System.out.println("\nDetalhes do Gato:");
        System.out.println(meuGato.toString());

        meuGato.miar();

        Cachorro Cachorro = new Cachorro(Porte.GRANDE, "Marrom", "Labrador", "Thor", 5);
        Gato Gato = new Gato(Porte.PEQUENO, "Branco", "Persa", "Bola", 3);

        List<Animal> animais = new ArrayList<>();

        animais.add(meuCachorro);
        animais.add(meuGato);
        animais.add(Cachorro);
        animais.add(Gato);
    }
}
