
public class Gato extends Animal {
    private Porte porte;
    private String cor;
    private String raca;

    public Gato(Porte porte, String cor, String raca, String nome, int idade) {
        super(nome, idade);
        this.porte = porte;
        this.cor = cor;
        this.raca = raca;
    }

    public Porte getPorte() {
        return porte;
    }

    public String getCor() {
        return cor;
    }

    public String getRaca() {
        return raca;
    }

    public void miar() {
        System.out.println("Miando...");
    }

    @Override

    public String toString() {
        return "Nome: " + getNome() + ", Idade: " + getIdade() + ", Porte: " + porte + ", Cor: " + cor + ", Raca: " + raca;
    }
}
