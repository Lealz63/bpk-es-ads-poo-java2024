public class Main {
    public static void main(String[] args) {
        Carro bmwAzul = new Carro("I4", "BMW", 2020, "Azul");

        System.out.println(bmwAzul);
    }
}