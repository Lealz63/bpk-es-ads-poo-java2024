package Exercicio_7;

public class Main {
    public static void main(String[] args) {
        Aluno aluno = new Aluno("Arthur", 202342, "E.S");
        aluno.calcular_media();
        System.out.println(aluno);
    }
}
