package Exercicio_16;

public class Main {
    public static void main(String[] args) {
        Loja loja = new Loja("Pernambucana", "45 99556-2592", "Rua bla bla");

        loja.abrir();;

        System.out.println(loja);
    }
}
