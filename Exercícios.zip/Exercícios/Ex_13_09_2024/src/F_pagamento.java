public enum F_pagamento {
    PIX,
    Credito,
    Debito,
    Dinheiro,
}
