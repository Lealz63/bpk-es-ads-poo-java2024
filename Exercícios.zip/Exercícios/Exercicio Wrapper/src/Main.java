public class Main {
    public static void main(String[] args) {
        Integer myInt = 5;
        Double myDouble = 5.99;
        Character myChar = 'A';
        System.out.println(myInt.intValue());
        System.out.println(myDouble.doubleValue());
        System.out.println(myChar.charValue());

        System.out.println(myDouble.intValue());
        System.out.println(myDouble.longValue());
        System.out.println(myDouble.equals(5.99));
    }
}