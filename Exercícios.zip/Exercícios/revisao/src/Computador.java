public class Computador {
    private String marca;
    private String processador;
    private Integer memoriaRam;

    // Construtor
    public Computador(String marca, String processador, Integer memoriaRam) {
        this.marca = marca;
        this.processador = processador;
        setMemoriaRam(memoriaRam); // Validação do valor no setter
    }

    // Getter para 'marca'
    public String getMarca() {
        return marca;
    }

    // Setter para 'marca'
    public void setMarca(String marca) {
        this.marca = marca;
    }

    // Getter para 'processador'
    public String getProcessador() {
        return processador;
    }

    // Setter para 'processador'
    public void setProcessador(String processador) {
        this.processador = processador;
    }

    // Getter para 'memoriaRam'
    public Integer getMemoriaRam() {
        return memoriaRam;
    }

    // Setter para 'memoriaRam' com validação
    public void setMemoriaRam(Integer memoriaRam) {
        if (memoriaRam != null && memoriaRam > 0) {
            this.memoriaRam = memoriaRam;
        } else {
            System.out.println("Erro: Memória RAM inválida.");
        }
    }

    // Método para exibir informações do computador
    public void exibirInfo() {
        System.out.println("Marca: " + marca + ", Processador: " + processador + ", Memória RAM: " + memoriaRam + "GB");
    }
}
