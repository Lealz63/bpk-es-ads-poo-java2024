public class Main {
    public static void main(String[] args) {
        Computador comp = new Computador("Intel", "I9", 56);
        comp.exibirInfo();
    }
}