import java.util.ArrayList;
import java.util.List;

public class MainEx2 {
    public static void main(String[] args) {
        Autor autor1 = new Autor("Machado de Assis", "Brasileiro");
        Autor autor2 = new Autor("J.K. Rowling", "Britânica");

        Livro livro1 = new Livro("Dom Casmurro", "1234567890", autor1);
        Livro livro2 = new Livro("Harry Potter e a Pedra Filosofal", "0987654321", autor2);
        Livro livro3 = new Livro("Memórias Póstumas de Brás Cubas", "1231231231", autor1);
        Livro livro4 = new Livro("Harry Potter e a Câmara Secreta", "3213213210", autor2);

        autor1.adicionarLivro(livro1);
        autor1.adicionarLivro(livro3);
        autor2.adicionarLivro(livro2);
        autor2.adicionarLivro(livro4);

        System.out.println("Informações dos autores e seus livros:\n");
        System.out.println(autor1);
        System.out.println(autor2);

        System.out.println("\nLivros escritos por " + autor1.getNome() + ":");
        listarLivros(autor1.getLivros());

        System.out.println("\nLivros escritos por " + autor2.getNome() + ":");
        listarLivros(autor2.getLivros());

        System.out.println("\nAlterando o nome do autor1...");
        autor1.setNome("José de Alencar");
        System.out.println(autor1);

        Livro livro5 = new Livro("O Guarani", "5555555555", autor1);
        autor1.adicionarLivro(livro5);
        System.out.println("\nApós adicionar mais um livro para " + autor1.getNome() + ":");
        listarLivros(autor1.getLivros());

        System.out.println("\nAlterando o ISBN de 'O Guarani'...");
        livro5.setIsbn("6666666666");
        System.out.println("Livro atualizado: " + livro5);
    }

    public static void listarLivros(List<Livro> livros) {
        for (Livro livro : livros) {
            System.out.println(livro);
        }
    }
}
