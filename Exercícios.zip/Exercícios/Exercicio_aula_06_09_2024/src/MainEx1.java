import java.util.ArrayList;
import java.util.List;

public class MainEx1 {
    public static void main(String[] args) {
        Endereco endereco1 = new Endereco("Rua Harmonia", 123, "Vila Madalena", "São Paulo", "SP", "05435-040");
        Endereco endereco2 = new Endereco("Av. Paulista", 1578, "Bela Vista", "São Paulo", "SP", "01310-200");

        List<Endereco> enderecosPessoa1 = new ArrayList<>();
        enderecosPessoa1.add(endereco1);
        enderecosPessoa1.add(endereco2);

        Pessoa pessoa1 = new Pessoa("João Silva", 30, enderecosPessoa1);

        System.out.println("Informações da pessoa:");
        System.out.println(pessoa1);

        Endereco endereco3 = new Endereco("Rua Consolação", 800, "Consolação", "São Paulo", "SP", "01302-000");
        pessoa1.adicionarEndereco(endereco3);

        System.out.println("\nApós adicionar novo endereço:");
        System.out.println(pessoa1);

        System.out.println("\nTestando getters e setters:");
        System.out.println("Nome: " + pessoa1.getNome());
        System.out.println("Idade: " + pessoa1.getIdade());
        pessoa1.setNome("Maria Silva");
        pessoa1.setIdade(35);
        System.out.println("Nome atualizado: " + pessoa1.getNome());
        System.out.println("Idade atualizada: " + pessoa1.getIdade());

        Endereco enderecoTeste = pessoa1.getEnderecos().get(0); // Pega o primeiro endereço da lista
        System.out.println("\nPrimeiro endereço:");
        System.out.println(enderecoTeste);

        enderecoTeste.setRua("Rua Nova");
        enderecoTeste.setNumero(555);
        enderecoTeste.setBairro("Novo Bairro");
        enderecoTeste.setCidade("Nova Cidade");
        enderecoTeste.setEstado("RJ");
        enderecoTeste.setCep("22222-000");

        System.out.println("Endereço atualizado:");
        System.out.println(enderecoTeste);
    }
}
